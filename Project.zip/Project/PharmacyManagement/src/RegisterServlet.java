
import java.sql.*;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Inventory.ConnectionFactory;

public class RegisterServlet extends HttpServlet {

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 Connection con = null;
		 Statement statement = null;
		// ResultSet rs = null;
		 long id=0;
		 con=ConnectionFactory.getConnection(); 
		 response.setContentType("text/html");
			PrintWriter pw=response.getWriter();
		 try {
			statement = con.createStatement();
			String s1=request.getParameter("username");
			String s2=request.getParameter("password");
			String s3=request.getParameter("name");
			String s4=request.getParameter("email");
			String s5=request.getParameter("phone_no");
			PreparedStatement pst=con.prepareStatement("insert into register values(?,?,?,?,?)");
			pst.setString(1,s1);  
			pst.setString(2,s2);  
			pst.setString(3,s3);  
			pst.setString(4,s4); 
			pst.setString(5,s5);
		int affectedRows =	pst.executeUpdate();
		
		if(affectedRows> 0)
		{
			try (ResultSet rs =pst.getGeneratedKeys()){
				 if (rs.next()) {
                     id = rs.getLong(1);
                 }
             } catch (SQLException ex) {
                 System.out.println(ex.getMessage());
             }
         }
     } catch (SQLException ex) {
         System.out.println(ex.getMessage());
     }
     return;
			}
		
			
		
		
	}


