package Inventory;
import java.sql.*;

public class ConnectionFactory {
     	    static Connection con = null;
		    Statement stmt = null;
		    ResultSet rs = null;
		    boolean flag=false;
		    
		    //Constructor starts
		   public Connection ConnectionFactory(){
		        try{
		            Class.forName("oracle.jdbc.driver.OracleDriver");
		            con=DriverManager.getConnection("jdbc:oracle:thin@localhost:1521:orcl","scott","tiger");
		            stmt=con.createStatement();
		        }catch(Exception e){
		            e.printStackTrace();
		        }
		        return con;
		    }//end of constructor ConnectionFactory
		    
		    //method Connection starts
		    public static Connection getConnection(){
		        
		            try {
						Class.forName("oracle.jdbc.driver.OracleDriver");
						con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","scott","tiger");
      
                     
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					return con;
		    }
		   
		    
		}